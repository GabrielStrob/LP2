﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pCalculadora
{
    public partial class Form1 : Form
    {
        double num1, num2, result; //variável global 

        public Form1()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtNum1.Text, out num1) &&
                double.TryParse(txtNum2.Text, out num2))
            {
                result = num1 + num2;
                txtNum3.Text = result.ToString();
            }

            else
                MessageBox.Show("Número Inválido");
        }
        private void btnSub_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtNum1.Text, out num1) &&
    double.TryParse(txtNum2.Text, out num2))
            {
                result = num1 - num2;
                txtNum3.Text = result.ToString();
            }

            else
                MessageBox.Show("Número Inválido");
        }
        private void btnMult_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtNum1.Text, out num1) &&
    double.TryParse(txtNum2.Text, out num2))
            {
                result = num1 * num2;
                txtNum3.Text = result.ToString();
            }

            else
                MessageBox.Show("Número Inválido");
        }
        private void btnDiv_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtNum1.Text, out num1) &&
    double.TryParse(txtNum2.Text, out num2))
            {
                if (num2 == 0)
                    MessageBox.Show("Não pode dividir por zero!");
                else
                {
                    result = num1 / num2;
                    txtNum3.Text = result.ToString();
                }
            }

            else
                MessageBox.Show("Número Inválido");
        }

        private void txtNum3_TextChanged(object sender, EventArgs e)
        {
            // Enable: false; Não permite copiar e colar o conteúdo, editar ou inserir
            // ReadOnly: true; Não permite inserir ou editar dados, mas permite copiar e colar em campo externo
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNum1.Clear();
            txtNum2.Clear();
            txtNum3.Clear();

            txtNum1.Focus();
        }
        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

    }
}
