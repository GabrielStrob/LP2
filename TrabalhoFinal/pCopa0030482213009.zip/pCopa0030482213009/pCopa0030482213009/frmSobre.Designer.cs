﻿namespace pCopa0030482213009
{
    partial class frmSobre
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSobre));
            this.btn_SairSobre = new System.Windows.Forms.Button();
            this.rchtxtSobre = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // btn_SairSobre
            // 
            this.btn_SairSobre.Location = new System.Drawing.Point(33, 223);
            this.btn_SairSobre.Name = "btn_SairSobre";
            this.btn_SairSobre.Size = new System.Drawing.Size(111, 33);
            this.btn_SairSobre.TabIndex = 0;
            this.btn_SairSobre.Text = "Sair";
            this.btn_SairSobre.UseVisualStyleBackColor = true;
            this.btn_SairSobre.Click += new System.EventHandler(this.btn_SairSobre_Click);
            // 
            // rchtxtSobre
            // 
            this.rchtxtSobre.Location = new System.Drawing.Point(23, 27);
            this.rchtxtSobre.Name = "rchtxtSobre";
            this.rchtxtSobre.Size = new System.Drawing.Size(396, 190);
            this.rchtxtSobre.TabIndex = 1;
            this.rchtxtSobre.Text = resources.GetString("rchtxtSobre.Text");
            this.rchtxtSobre.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
            // 
            // frmSobre
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(541, 297);
            this.Controls.Add(this.rchtxtSobre);
            this.Controls.Add(this.btn_SairSobre);
            this.Name = "frmSobre";
            this.Text = "frmSobre";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_SairSobre;
        private System.Windows.Forms.RichTextBox rchtxtSobre;
    }
}