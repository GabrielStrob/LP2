﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace pAtividade8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEx1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string aux = "", saida = "";

            for(int c = 0; c < vetor.Length; c++)
            {
                aux = Interaction.InputBox("Digite o " + (c+1).ToString() + "º número", "Entrada de Dados"); //chamar o InputBox tem que usar o Interaction.

                if (aux == "")
                    break;

                if (!int.TryParse(aux, out vetor[c]))
                {
                    MessageBox.Show("Dado inválido");
                    c--;
                }
                else
                    saida = vetor[c] + "\n" + saida;
            }
            /*aux = "";
            for(int c = vetor.Length-1; c >= 0; c--)
                aux += vetor[c] + "\n";*/
            
            MessageBox.Show(saida);
        }

        private void btnEx2_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string aux = "", saida = "";
            int c = 0;

            while(c < vetor.Length)
            {
                aux = Interaction.InputBox("Digite o " + (c + 1).ToString() + "º número", "Entrada de Dados"); //chamar o InputBox tem que usar o Interaction.

                if (aux == "")
                    break;

                if (!int.TryParse(aux, out vetor[c]))
                {
                    MessageBox.Show("Dado inválido");
                    c--;
                }
                c++;
            }

            Array.Reverse(vetor);
            foreach (int i in vetor)
                saida += i.ToString() + "\n";

            MessageBox.Show(saida);
        }

        private void btnEx3_Click(object sender, EventArgs e)
        {
            double[] preco = new double[10];
            double total = 0;
            int[] qtd = new int[10];
            string auxP = "", auxQ = "";
            
            for(int c = 0; c < qtd.Length; c++)
            {
                auxP = Interaction.InputBox("Digite o preço da mercadoria " + (c + 1).ToString(), "Preço");
                auxQ = Interaction.InputBox("Digite a quantidade da mercadoria " + (c + 1).ToString(), "Quantidade");

                if (auxP == "" && auxQ =="")
                    break;

                if (!int.TryParse(auxQ, out qtd[c]) & !double.TryParse(auxP, out preco[c]))
                {
                    MessageBox.Show("Dado inválido");
                    c--;
                }                
            }

            for(int c = 0; c < preco.Length; c++)
                total = total + (preco[c] * qtd[c]); 

            MessageBox.Show("Faturamento mensal:    R$ " + total);
        }

        private void btnEx4_Click(object sender, EventArgs e)
        {
            string[] Alunos = {"Viviane", "André", "Hélio", "Denise", "Junior", "Leonardo", "Jose", "Nelma", "Tobby"};
            Int32 I, Total = 0;
            Int32 N = Alunos.Length;
            for (I = 0; I < N - 1; I++)
            {
                Total += Alunos[I].Length;
            }
        }

        private void btnEx5_Click(object sender, EventArgs e)
        {
            ArrayList alunos = new ArrayList (new string[] { "Ana", "André", "Débora", "Fátima", "João", "Janete", "Otávio", "Marcelo", "Pedro", "Thais" } );
            string saida = "";

            foreach (string s in alunos)
                saida += s.ToString() + "\n";
            MessageBox.Show("Antes: \n" + saida);

            alunos.Remove("Otávio");

            saida = "";
            foreach (string s in alunos)
                saida += s.ToString() + "\n";
            MessageBox.Show("Depois: \n" + saida);
        }

        private void btnEx6_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            string nota1, nota2, nota3;
            double media;
            string stringone="";

            for (int c = 0; c < notas.GetLength(0)/*Número de colunas da Array*/; c++)
            {
                nota1 = Interaction.InputBox("Digite a nota 1 do Aluno " + (c + 1).ToString(), "Nota 1");
                nota2 = Interaction.InputBox("Digite a nota 2 do Aluno " + (c + 1).ToString(), "Nota 2");
                nota3 = Interaction.InputBox("Digite a nota 3 do Aluno " + (c + 1).ToString(), "Nota 3");

                if (nota1 == "" | nota2 == "" | nota3 == "")
                    break;

                if (!double.TryParse(nota1, out notas[c, 0]) &
                    !double.TryParse(nota2, out notas[c, 1]) &
                    !double.TryParse(nota3, out notas[c, 2]))
                {
                    MessageBox.Show("Dado inválido");
                    c--;
                }
            }

            for (int c = 0; c < notas.GetLength(0); c++)
            {
                media = (notas[c, 0] + notas[c, 1] + notas[c, 2]) / 3;
                stringone += "Média do aluno " + (c + 1) + ": " + media.ToString("N2") + "\n";
            }              

            MessageBox.Show(stringone);
        }

        private void btnEx7_Click(object sender, EventArgs e)
        {
            frmEx7 frmEx7 = new frmEx7();
            frmEx7.Show();

            /*string[] nome = new string[7];
            string nAux="", stringona="";
            int[] chars = new int[7];
            int c=0;

            while (c < nome.Length)
            {
                nome[c] = Interaction.InputBox("Digite um nome: ", "Nome "+(c+1).ToString());
                nAux = nome[c].Replace(" ","");

                chars[c] = nAux.Length;
                nAux = "";
                c++;
            }

            for (c = 0; c < nome.Length; c++)
                stringona += "O nome: " + nome[c] + " tem " + chars[c] + " characters.\n";

            MessageBox.Show(stringona);*/
        }
    }
}
