﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace pAtividade8
{
    public partial class frmEx7 : Form
    {
        public frmEx7()
        {
            InitializeComponent();
            //RA 003048202302 7
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string[] nomes = new string[7];
            string nAux = "", stringona = "";
            int[] chars = new int[7];
            int c = 0;

            while (c < nomes.Length)
            {                
                nomes[c] = Interaction.InputBox("Digite um nome: ", "Nome " + (c + 1).ToString());

                if (nomes[c] == "")
                    break;

                nAux = nomes[c].Replace(" ", "");
                chars[c] = nAux.Length;
                nAux = "";
                c++;
            }

            for (c = 0; c < nomes.Length; c++)
                stringona += "O nome " + nomes[c] + " tem " + chars[c] + " characters.\n";

            rtxtNomes.Text = stringona;
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            rtxtNomes.Clear();
        }
    }
}
