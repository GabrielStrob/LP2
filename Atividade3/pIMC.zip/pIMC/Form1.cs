﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pIMC
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtAltura.Text, out var altura) && double.TryParse(txtPeso.Text, out var peso)) //Validação se número
            {
                if (altura > 0 && peso > 0) //Validação se zero
                {
                    double imc = peso / (altura * altura);//calculo IMC
                    imc = Math.Round(imc, 1);

                    if (imc < 18.5)
                    {
                        txtIMC.Text = "IMC = " + imc + " | Classificação: " + "Magreza";
                    }
                    else if (imc < 25)
                    {
                        txtIMC.Text = "IMC = " + imc + " | Classificação: " + "Normal";
                    }
                    else if (imc < 30)
                    {
                        txtIMC.Text = "IMC = " + imc + " |  Classificação: " + "Sobrepeso";
                    }
                    else if (imc < 40)
                    {
                        txtIMC.Text = "IMC = " + imc + " | Classificação: " + "Obesidade";
                    }
                    else if (imc > 39.9)
                    {
                        txtIMC.Text = "IMC = " + imc + " | Classificação: " + "Obesidade Grave";
                    }
                        
                }

                else
                    MessageBox.Show("O número deve ser maior que zero!");
            }
            else
                MessageBox.Show("Número Inválido!");

        }

        private void btnLimpar_Click(object sender, EventArgs e) //Botão Limpar
        {
            txtAltura.Clear();
            txtPeso.Clear();
            txtIMC.Clear();

            txtPeso.Focus();
        }

        private void btnSair_Click(object sender, EventArgs e) //Botão Sair
        {
            Close();
        }
    }
}
