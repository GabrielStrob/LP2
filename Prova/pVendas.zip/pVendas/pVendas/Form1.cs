﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace pVendas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            lbxSaida.Items.Clear();
            double[,] vendas = new double[9, 4];
            string aux = "";

            for (int l = 0; l < vendas.GetLength(0); l++)   /*laço if para rodar a leitura dos valores através dos meses*/
            {
                for (int c = 0; c < vendas.GetLength(1); c++)    /*laço if para rodar a leitura dos valores através das semanas*/
                {
                    aux = Interaction.InputBox(String.Format("Valor da {0}ª semana,\ndo {1}º mês.", (c + 1), (l + 1)), "$ Entrada de valores recebidos $");    /*código para fazer a leitura dos valores*/


                    if (!double.TryParse(aux, out vendas[l, c]))
                    {
                        MessageBox.Show("Dado Inválido");
                        c--;
                    }
                }
            }

            double totalMes, totalGeral = 0;

            for (int l = 0; l < vendas.GetLength(0); l++)
            {
                totalMes = 0;
                lbxSaida.Items.Add("Total do mês " + Convert.ToString(l + 1));
                for (int c = 0; c < vendas.GetLength(1); c++)
                {
                    lbxSaida.Items.Add(String.Format("   •   Semana {0}: {1:C2}", (c + 1), vendas[l, c]));
                    totalMes += vendas[l, c];
                }
                lbxSaida.Items.Add(String.Format("   >> Total do mês: {0:C2}", totalMes));
                lbxSaida.Items.Add("");
                totalGeral += totalMes;
            }
            lbxSaida.Items.Add(String.Format("Total Geral: {0:C2}", totalGeral));

        }
    }
}
